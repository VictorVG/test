local F=far.Flags
local tin=table.insert
local BAX=_G.BAX
local DialogItem, DialogItemVal=BAX.BaxUtils.DialogItem, BAX.BaxUtils.DialogItemVal
local PathName,FarLang,HlpLang = (...):match("(.*)%.lua"),win.GetEnv("FARLANG"):sub(1,3),Far.GetConfig("Language.Help"):sub(1,3)
local HlfName, LngName
local CP_UTF8, CP_ANSI, CP_OEM=1,2,3
-----------------------------------------------------------------------------
-- Функция определения имени языкового файла (в зависимости от расширения)
local function LangFileName(Ext)
 local Res = PathName..HlpLang..Ext
 if not mf.fexist(Res) then Res = PathName..FarLang..Ext end
 if not mf.fexist(Res) then Res = PathName..Ext end
 if not mf.fexist(Res) then
  Res = far.RecursiveSearch(mf.fsplit(PathName, 3), mf.fsplit(PathName, 12) .. '*.lng', function(full) return full.FileName end, F.FRS_RETUPDIR)
  if Res then Res = mf.fsplit(PathName, 3) .. Res end
 end
 return Res
end
-----------------------------------------------------------------------------
HlfName = LangFileName".hlf"
LngName = LangFileName".lng"
-----------------------------------------------------------------------------
local FlagsToNumber=BAX.BaxUtils.FlagsToNumber
local TestFarFlag=_G.BAX.BaxUtils.TestFarFlag
local SetingKey={Author='BAX'; Key='Find_n_Go'}
local Dialog_Exec, Find_n_Go, SetupExt
local LngMsg = {}
local GetMsg=function(tag)
 if LngMsg[tag] == nil then
  LngMsg[tag] = BAX.GetMsg(LngName, tag, true)
 end
 return LngMsg[tag]
end
local far_Menu=BAX.BaxUtils.far_Menu

-------------------------------------------------------------------------------
--local HelpString, HelpTitle= GetMsg(LngName, 'HelpString', true),
--                             GetMsg(LngName, 'HelpTitle', true)
-----------------------------------------------------------------------------
local HelpString, HelpTitle= GetMsg"HelpString",
                             GetMsg"HelpTitle"
-----------------------------------------------------------------------------

local Info = package.loaded.regscript or function(...) return ... end
local nfo = Info {_filename or ...,
  name        = "Find_n_Go.lua";
  description = "Поиск по файлам с переходом в редакторе на найденную строку";
  version     = "1.0.2"; --http://semver.org/lang/ru/
  author      = "BAX";
  url         = "";
  id          = "BFC2710A-3FD6-4B54-9ADE-0C78E1FCE315";
  --parent_id   = "";
  --minfarversion = {3,0,0,4744,0};
  files       = "*.cfg;*.lng;*.hlf";
  --config      = function(nfo,name) end;
  help        = function(nfo,name)
    if HlfName then
     far.ShowHelp(HlfName, 'main', 'FHELP_CUSTOMFILE')
    else
     far.Message(HelpString, HelpTitle, nil, F.FMSG_LEFTALIGN)
    end

  end;
  execute     = function(nfo,name)
   local aPar=Dialog_Exec()
   if aPar then
    Find_n_Go(aPar)
   end
  end;

  --disabled    = false;
  --options     = {};
}
if not nfo then return end
--local O = nfo.options
------------------------------------------------------------------------------
function Dialog_Exec()
 local Settings = mf.mload(SetingKey.Author, SetingKey.Key) or
       {Recursive=true; CP_All=true, Plain=true}
 local DlgItems, y={}, 2
 local PrevCP=0
 local function Add(Arg)
  local it=type(Arg[1]) == 'string' and F[Arg[1]] or Arg[1]
  if Arg.Name and Arg.Name:sub(1,1) ~= '_' then
   if it == F.DI_EDIT or it == F.DI_FIXEDIT  then
    if Arg.Text == nil and
       Settings[Arg.Name] then
     Arg.Text = Settings[Arg.Name]
    end
   elseif it == F.DI_CHECKBOX or it == F.DI_RADIOBUTTON then
    if Arg.Checked == nil and
       Arg.Selected == nil then
     Arg.Checked = Settings[Arg.Name] and 1 or 0
     if Arg.Checked == 1 and
        Arg.Name:match"^CP_" then
      PrevCP = #DlgItems+1
     end
    end
   end
  end -- if Arg.Name
  tin(DlgItems, DialogItem(Arg))
 end
 -------------------------------------------------
 local function ItemByName(name)
  for i,v in ipairs(DlgItems) do
   if v.Name and v.Name == name then
    return v, i
   end
  end
 end
 -------------------------------------------------
 local function AddP(Arg, dy) Add(Arg); y=y+(dy or 1) end
 local w=math.floor(math.min(200, Far.Width*0.8))
 ------------------------------------------------------------------------------------------------
 Add{"DI_DOUBLEBOX",0,0,w-1,0;Text=GetMsg"DlgTitle"}
 ------------------------------------------------------------------------------------------------
 --Add{"DI_TEXT"; x1=2; y1=y; Text="&0. Искать в каталоге"}
 Add{"DI_TEXT"; x1=2; y1=y; Text=GetMsg"&0"}
 Add{"DI_EDIT"; x1=25; y1=y; x2=w-26; Text=win.GetCurrentDir(); Flags="DIF_EDITPATH|DIF_HISTORY"; History="Path"; Name='_Path'}
 AddP({"DI_CHECKBOX"; x1=w-22; y1=y; Text=GetMsg"Recur"; Name='Recursive'}, 2)
 ------------------------------------------------------------------------------------------------
 Add{"DI_TEXT"; x1=2; y1=y; Text=GetMsg"&1"; }
 AddP({"DI_EDIT"; x1=25; x2=w-4; y1=y; History="Masks"; Flags="DIF_HISTORY|DIF_FOCUS"; Name='FileMask'}, 2)
 Add{"DI_TEXT"; x1=2; y1=y; Text=GetMsg"&2"; }
 AddP({"DI_EDIT"; x1=25; y1=y; x2=w-4; History="SearchText"; Flags="DIF_HISTORY|DIF_USELASTHISTORY"; Name='_SearchText'}, 2)
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"&3"; Flags="DIF_CENTERGROUP|DIF_GROUP"; Name='reFar'}
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"&4"; Flags="DIF_CENTERGROUP"; Name='rePerl'}
 AddP({"DI_RADIOBUTTON"; y1=y; Text=GetMsg"&5";            Flags="DIF_CENTERGROUP"; Name='Plain'})
 AddP{"DI_TEXT"; y1=y; Text=GetMsg"&6"; Flags="DIF_CENTERGROUP"}
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"UTF-8" ; Flags="DIF_GROUP|DIF_CENTERGROUP"; Name='CP_UTF8'}
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"ANSI"  ; Flags="DIF_CENTERGROUP"; Name='CP_ANSI'}
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"OEM"   ; Flags="DIF_CENTERGROUP";  Name='CP_OEM'}
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"CpAll" ; Flags="DIF_CENTERGROUP";  Name='CP_All'}
 Add{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"Auto"; Flags="DIF_CENTERGROUP"; Name='CP_Auto'} -- за ним на следующий не перейти...
 AddP{"DI_RADIOBUTTON"; y1=y; Text=GetMsg"CpExt"; Flags="DIF_CENTERGROUP"; Name='CP_Ext'}
 AddP{"DI_BUTTON"; y1=y; Text=GetMsg"SetupExt"; Flags="DIF_CENTERGROUP|DIF_BTNNOCLOSE" .. (DialogItemVal(ItemByName('CP_Ext'), 'Checked')==0 and '|DIF_DISABLE' or ''); Name='SetupExt'}
 ------------------------------------------------------------------------------------------------
 AddP({"DI_TEXT"; y1=y; Flags="DIF_SEPARATOR|DIF_BOXCOLOR"})
 Add{"DI_BUTTON"; y1=y; Text="Find"; Flags="DIF_DEFAULTBUTTON|DIF_CENTERGROUP"; Name='Find'}
 Add{"DI_BUTTON"; y1=y; Text="Cancel"; Flags="DIF_CENTERGROUP"}
 Add{"DI_BUTTON"; y1=y; Text="Help"; Flags="DIF_BTNNOCLOSE|DIF_CENTERGROUP"; Name='Help'}
 local h = y + 2
 ------------------------------------------------
 do
  local first=DlgItems[1]
  first.y2=h-1
  DlgItems[1] = DialogItem(first)
 end
 ------------------------------------------------
 local Busy=false
 local function DlgProc(hDlg,Msg,Param1,Param2)
  if Busy then return end
  if (Msg == F.DN_BTNCLICK and DlgItems[Param1] and (DlgItems[Param1].Name or '') == 'Help')
       or
     (Msg == F.DN_CONTROLINPUT and Param2.EventType == F.KEY_EVENT and far.InputRecordToName(Param2) == 'F1')
  then
   if HlfName then
    far.ShowHelp(HlfName, 'menu', 'FHELP_CUSTOMFILE')
   else
    far.Message(HelpString, HelpTitle, nil, F.FMSG_LEFTALIGN)
   end
  elseif Msg == F.DN_BTNCLICK and DlgItems[Param1] and (DlgItems[Param1].Name or ''):match"CP_" then
   local Checked=hDlg:send("DM_GETCHECK", Param1)
   if (DlgItems[Param1].Name or '')=="CP_Ext" then
    local _, iItem=ItemByName('SetupExt')
    if iItem then hDlg:send("DM_ENABLE", iItem, Checked) end
    -- Проверка, заданы ли соответствия расшмрений ми CP
    if Checked == 1 and not next(mf.mload(SetingKey.Author, SetingKey.Key .. '.ExtList') or {}) then
     local iChoice=far.Message(GetMsg"EmptyCPExtDependence", GetMsg"ScriptTitle", GetMsg";YesNoIgnore" )
     if iChoice==1 then
      SetupExt()
     elseif iChoice==2 then
      --hDlg:send("DM_SETFOCUS", PrevCP)
      Busy = true
      hDlg:send("DM_SETCHECK", PrevCP, 1)
      Busy = false
     else
      PrevCP = Param1
     end
    end
   --elseif (DlgItems[Param1].Name or '')=="CP_Auto" and Checked then
   -- far.Message('Автоматическое определение кодовой страницы не реализовано', GetMsg"ScriptTitle", nil, 'w')
   -- Busy = true
   -- hDlg:send("DM_SETCHECK", PrevCP, 1)
   -- Busy = false
   else
    if Checked == 1 then
     PrevCP = Param1
    end
   end
  elseif Msg == F.DN_BTNCLICK and DlgItems[Param1] and (DlgItems[Param1].Name or '')=="SetupExt" then
   SetupExt()
  end
 end -- DlgProc
 ------------------------------------------------
 local iRes=far.Dialog(win.Uuid"F2F09294-EADC-47DD-A3B5-A30B7277D239",  -1,-1,w,h,nil,DlgItems,F.FDLG_SMALLDIALOG, DlgProc)
 if DlgItems[iRes] and DlgItems[iRes].Name == 'Find' then
  Settings = {}
  for _,v in ipairs(DlgItems) do
   if v.Name and v.Name:sub(1,1) ~= '_' then
    local it=type(v[1]) == 'string' and F[v[1]] or v[1]
    if it == F.DI_EDIT or it == F.DI_FIXEDIT  then
     Settings[v.Name] = DialogItemVal(v, 'Text')
    elseif it == F.DI_CHECKBOX or it == F.DI_RADIOBUTTON then
     Settings[v.Name] = DialogItemVal(v, 'Checked')==1
    end
   end
  end
  mf.msave(SetingKey.Author, SetingKey.Key, Settings)
  local aResult={}
  for _,v in ipairs(DlgItems) do
   if v.Name then
    local it=type(v[1]) == 'string' and F[v[1]] or v[1]
    if it == F.DI_EDIT or it == F.DI_FIXEDIT  then
     aResult[v.Name] = DialogItemVal(v, 'Text')
    elseif it == F.DI_CHECKBOX or it == F.DI_RADIOBUTTON then
     aResult[v.Name] = DialogItemVal(v, 'Checked')==1
    end
   end
  end
  return aResult
 end
end -- Dialog_Exec

function SetupExt()
 local Busy=false
 local y=2
 local DlgItems={}
 local function Add(Arg) tin(DlgItems, DialogItem(Arg)) end
 local function AddP(Arg, dy) Add(Arg); y=y+(dy or 1) end
 -------------------------------------------------
 local w=math.floor(math.min(200, Far.Width*0.8))
 local RadioButtons ={}
 local ListItems= mf.mload(SetingKey.Author, SetingKey.Key .. '.ExtList') or
                 { PreviewCount = 3;
                   {Text="*.lua,*.fml,*.fmlua,*.hlf,*.lng"; UserData=CP_UTF8;};
                   {Text="*.pas,*.dfm,*.dpr,*.inc"; UserData=CP_ANSI;};
                   {Text="*.prg,*.ch,*.bat,*.cmd"; UserData=CP_OEM;};
                 }
 tin(ListItems, {Text=GetMsg"AddMask"; UserData=0;})
 -------------------------------------------------
 --[[ 1]]Add{"DI_DOUBLEBOX",0,0,w-1,0;Text=GetMsg"SetupExtTitle"}
 --[[ 2]]AddP({"DI_LISTBOX"; x1=10; x2=w-10;y1=y; y2=y+10;
               --Flags="DIF_LISTWRAPMODE|DIF_LISTNOBOX|DIF_LISTNOCLOSE",
               Flags="DIF_LISTWRAPMODE|DIF_LISTNOCLOSE",
               ListItems=ListItems
              }, 12); local ListID=#DlgItems
 --[[ 3]]Add{"DI_TEXT"; x1=5; y1=y; Text=GetMsg"FileMask"; }
 --[[ 4]]Add{"DI_EDIT"; y1=y; x1=17;x2=w-35;}; local EditID=#DlgItems
 --[[ 5]]Add{"DI_RADIOBUTTON"; y1=y; x1=w-33; Text="UTF"; Name="CP_UTF"; UserData=CP_UTF8; Flags="DIF_GROUP"};    RadioButtons[CP_UTF8] = #DlgItems
 --[[ 6]]Add{"DI_RADIOBUTTON"; y1=y; x1=w-25; Text="ANSI"; Name="CP_ANSI"; UserData=CP_ANSI; }                    RadioButtons[CP_ANSI] = #DlgItems
 --[[ 7]]Add{"DI_RADIOBUTTON"; y1=y; x1=w-17; Text="OEM"; Name="CP_OEM"; UserData=CP_OEM; }                       RadioButtons[CP_OEM ] = #DlgItems
 --[[ 8]]AddP{"DI_BUTTON"; y1=y; x1=w-7; Text="=>"; Name="Apply"; Flags="DIF_BTNNOCLOSE|DIF_NOBRACKETS"}
 --[[ 9]]AddP{"DI_TEXT"; y1=y; Flags="DIF_SEPARATOR|DIF_BOXCOLOR"}
 --[[10]]Add{"DI_BUTTON"; Text='Ok'; y1=y; Flags="DIF_DEFAULTBUTTON|DIF_CENTERGROUP"; Name="OkButton"}
 --[[11]]Add{"DI_BUTTON"; Text='Cancel'; y1=y; Flags="DIF_CENTERGROUP"}
 local h=y+2
 do
  local first=DlgItems[1]
  first.y2=h-1
  DlgItems[1] = DialogItem(first)
 end
 local CurrCP=0
 local function DlgProc(hDlg, Msg, Param1, Param2)
  local function _Load(Pos)
   if not Busy then
     if Pos > 0 and Pos < #ListItems then
      hDlg:send("DM_SETTEXT", EditID, ListItems[Pos].Text)
     else
      hDlg:send("DM_SETTEXT", EditID, '')
     end
     CurrCP = ListItems[Pos].UserData > 1 and ListItems[Pos].UserData or 1
     hDlg:send("DM_SETCHECK", RadioButtons[CurrCP], 1)
   end
  end -- _Load
  --local function _Save(Pos)
  -- hDlg:send("DM_LISTSETDATA -- DI_LISTBOX
  -- SETTEXT", ListID,
  --end
  if Msg == F.DN_INITDIALOG or
     Msg == F.DN_LISTCHANGE then
   if Msg == F.DN_INITDIALOG then
    hDlg:send("DM_LISTSETCURPOS", ListID, {SelectPos=1})
    Param2 = 1
   end
   _Load(Param2)
  elseif Msg == F.DN_BTNCLICK and
     (DlgItems[Param1].Name or '') == 'Apply' then
   Busy = true
   local CurrPos=hDlg:send("DM_LISTGETCURPOS", ListID).SelectPos
   local NewText=hDlg:send("DM_GETTEXT", EditID)
   if CurrPos == #ListItems then
    local NewItem={Text=NewText; UserData=CurrCP }
    hDlg:send("DM_LISTINSERT", ListID, {Index=#ListItems; Item=NewItem})
    hDlg:send("DM_LISTSETCURPOS", ListID, {SelectPos=CurrPos})
    hDlg:send("DM_SETTEXT", ListID, NewText)
    tin(ListItems, #ListItems, NewItem)
   else
    hDlg:send( "DM_SETTEXT", ListID, NewText )
    ListItems[CurrPos].Text = NewText
    ListItems[CurrPos].UserData = CurrCP
   end
   hDlg:send("DM_SETFOCUS", ListID)
   Busy = false
  elseif Msg == F.DN_BTNCLICK and
         (DlgItems[Param1].Name or ''):match"^CP_" and
         hDlg:send("DM_GETCHECK", Param1) == 1 then
   CurrCP = DialogItemVal(DlgItems[Param1], 'UserData')
  end
 end
 local iRes=far.Dialog(win.Uuid"AB37A7A1-AD1E-4FBF-B319-E1FE2C0BBE61", -1,-1,w,h,nil,DlgItems,F.FDLG_SMALLDIALOG, DlgProc)
 if type(iRes)=='number' and DlgItems[iRes] and (DlgItems[iRes].Name or '') == 'OkButton' then
  table.remove(ListItems)
  mf.msave(SetingKey.Author, SetingKey.Key .. '.ExtList', ListItems)
 end
end -- SetupExt

function Find_n_Go(aPar)
 local FList={}
 local Root=aPar._Path
 if Root:sub(-1) ~= '\\' then Root = Root .. '\\' end
 far.RecursiveSearch(Root, aPar.FileMask, function(FInfo,FName) if not FInfo.FileAttributes:find"d" then tin(FList, FName) end end, aPar.Recursive and F.FRS_RECUR or F.FRS_NONE)
 if #FList == 0 then
  far.Message(GetMsg"File_Not_Found", GetMsg"ScriptTitle", nil, 'w')
  return
 end
 local MaxL, aMenu, PrevF=0, {}, ''

 local function f1(S,P) return S:lower():find(P:lower(), 1, true) end
 local function f2(S,P) return S:match(P) end
 local function f3(S,P) return regex.match(S, P) end
 local SearchFunc
 if aPar.Plain then SearchFunc = f1
 elseif aPar.rePerl then SearchFunc = f3
 else SearchFunc = f2
 end
 local ListItems= mf.mload(SetingKey.Author, SetingKey.Key .. '.ExtList') or
       { {Text='*.pas,*.dfm,*.dpr,*.inc'; UserData=CP_ANSI};
         {Text='*.prg,*.ch,*.cmd,*.bat'; UserData=CP_OEM};
         {Text='*.lua,*.hrc,*.xml,*.htm,*.html,*.aff'; UserData=CP_UTF8};
       }
 local Time, aLog, MaxLog=Far.UpTime, {}, APanel.Height-10
 for _,v in ipairs(FList) do
  local AutoCP
  if Far.UpTime > Time+200 then
   Time = Far.UpTime
   far.Message(table.concat(aLog, '\n') .. (#aLog > 0 and '\n\2\n' or '') .. v, 'Find_n_Go','', 'l')
   if mf.waitkey(1) == 'Esc' then
    local iChoice = far.Message(GetMsg"Interrupt", 'Find_n_Go', GetMsg"YesNoEnough")
    if iChoice == 1 then
     aMenu = {}
     break
    elseif iChoice == 3 then break
    end
   end
   far.AdvControl("ACTL_REDRAWALL")
  end
  if aPar.CP_Auto then
   -- Определяю CP - открываю файл в редакторе и получаю его кодовую страницу
   editor.Editor(v, nil, nil, nil, nil, nil,
                 FlagsToNumber("EF_IMMEDIATERETURN|EF_DISABLEHISTORY|EF_DISABLESAVEPOS|EF_OPENMODE_NEWIFOPEN|EF_NONMODAL"),1,1 )
   local ei=editor.GetInfo()
   if ei then
    if ei.CodePage == 866 then AutoCP = CP_OEM
    elseif ei.CodePage == 1251 then AutoCP = CP_ANSI
    elseif ei.CodePage == 65001 then AutoCP = CP_UTF8
    end
   end
   editor.Quit()
  end
  local iL = 0
  local StrBuffer={} -- Массив для сохранения нескольких (3-х для начала) строк, предшествующих найденной
  local aBuffList={} -- Массив 7-строчных буферов для найденных строк
  for l in io.lines(v) do
   iL = iL + 1
   local ll
   local iCP_1, iCP_2 = math.min(CP_UTF8, CP_ANSI, CP_OEM), math.max(CP_UTF8, CP_ANSI, CP_OEM) -- 1,3
   if AutoCP then
    iCP_1,iCP_2 = AutoCP, AutoCP
   elseif aPar.CP_UTF8 then
    iCP_1, iCP_2 = CP_UTF8,CP_UTF8
   elseif aPar.CP_OEM then
    iCP_1, iCP_2 = CP_OEM,CP_OEM
   elseif aPar.CP_ANSI then
    iCP_1, iCP_2 = CP_ANSI,CP_ANSI
   elseif aPar.CP_Ext then
    for _,w in ipairs(ListItems) do
     if far.ProcessName(F.PN_CMPNAMELIST, w.Text, v, F.PN_SKIPPATH) then
      iCP_1, iCP_2 = w.UserData,w.UserData
      break
     end
    end
   end
   for iCP=iCP_1,iCP_2 do
    if iCP==CP_UTF8 then
     ll = l                           -- UTF-8
    elseif iCP==CP_OEM then
     ll = win.OemToUtf8(l)            -- OEM
    else
     ll = BAX.BaxUtils.ANSItoUTF_8(l) -- ANSI
    end
    -- Занесение строки в буфер
    if #StrBuffer > 3 then table.remove(StrBuffer, 1) end
    tin(StrBuffer, ll);

    if SearchFunc(ll, aPar._SearchText) then
     if v~= PrevF then
      PrevF = v
      tin(aMenu, {text=v:sub(Root:len()+1); separator=true})
      if #aLog > MaxLog then table.remove(aLog,1) end
      tin(aLog, '\1'..v:sub(Root:len()+1))
     end
     tin(aMenu, {text=ll; fn=v; iL=iL; });
     if #aLog > MaxLog then table.remove(aLog,1) end
     tin(aLog, ll)
     do
      local Buff={}
      for _,b in ipairs(StrBuffer) do
       tin(Buff,b)
      end
      tin(aBuffList, {iL=iL; Buff=Buff; jL=#aMenu; Curl=#Buff})
      ----[[*D*]]far.Show('418: Buff=', table.concat(Buff, '\n'))
     end
     break
    end -- if SearchFunс
   end -- for iCP=iCP_1,iCP_2
   -- Добавление буфера в список буферов
   for j=#aBuffList,1,-1 do
    local b=aBuffList[j]
    if #b.Buff <= 6 and iL > aMenu[b.jL].iL then
     tin(b.Buff, ll);
     if #b.Buff == 7 then
      aMenu[b.jL].StrBuffer = b.Buff
      for _,s in ipairs(aMenu[b.jL].StrBuffer) do
       MaxL = math.max(MaxL, s:len())
      end
      aMenu[b.jL].Curl = b.Curl
      table.remove(aBuffList, j)
     end
    end
   end
  end -- for l in io.lines(v)
  if #aBuffList > 0 then
   for j=#aBuffList,1,-1 do
    local b=aBuffList[j]
    aMenu[b.jL].StrBuffer = b.Buff
    for _,s in ipairs(aMenu[b.jL].StrBuffer) do
     MaxL = math.max(MaxL, s:len())
    end

    aMenu[b.jL].Curl = b.Curl
    table.remove(aBuffList, j)
   end
  end
 end -- for _,v in ipairs(FList)
 far.AdvControl("ACTL_REDRAWALL")
 if #aMenu == 0 then
  far.Message(GetMsg"Pattern_Not_Found", GetMsg"ScriptTitle", nil, 'w')
  return
 end
 MaxL = math.min(MaxL, Far.Width-4)
 aMenu.MaxL = MaxL+4
  ----[[*D*]]far.Show('462: aMenu[2]:', BAX.TabUtils.TableToString(aMenu[2], ';\n', ' ')); if math.pi>0 then return end
 for _,m in ipairs(aMenu) do
  if m.StrBuffer then
   for i,s in ipairs(m.StrBuffer) do
    m.StrBuffer[i] = ' '..(s .. (' '):rep(MaxL-s:len()))..' '
   end
  end
 end
 local function MenuBottom(count)
  local format=GetMsg"MenuBottom"
  if (count or 0) > 0 then
   format = format:gsub('|', ' ', 1)
  else
   format = format:match"^(.*)|"
  end
  return format:format(count)
 end
 ----[[*D*]]local iOld,iNew=0,0
 local function FindByName(Items, Name)
  for i,v in ipairs(Items) do
   if v.Name and v.Name == Name then return i end
  end
 end
 local SelSimb=' ' -- '■'
 local Busy=false
 local ChkCount=0
 local Props={Bottom=MenuBottom(); SelectIndex=2;
              Y=2;
              MaxHeight=Far.Height - 14;
              MaxWidth=Far.Width - 40;
              Title=(GetMsg"ResTitle"):format(aPar._SearchText, aPar.FileMask);
              MaxWidh=Far.Width-8;
              HelpTopic='menu';
              HelpFile = HlfName;
              UserDlgHandler = function(hDlg, Msg, ItemId, Param2, DlgItems)
                                if Msg == F.DN_CTLCOLORDLGITEM and
                                   (DlgItems[ItemId].Name or ''):match('^BotText_') then
                                 if hDlg:send("DM_GETTEXT",ItemId):sub(1,1) == SelSimb then
                                  local SelColor = far.AdvControl(far.Flags.ACTL_GETCOLOR, far.Colors.COL_HELPTOPIC)
                                  Param2[1].ForegroundColor = SelColor.ForegroundColor
                                  Param2[1].BackgroundColor = SelColor.BackgroundColor
                                  Param2[1].Flags = SelColor.Flags
                                  return true, Param2
                                 end
                                end
                               end;
              OnListChange = function(hDlg, ItemID, Old, New, DlgItems)
                              if Busy then return end
                              for i=1,7 do
                               local iBotText = FindByName(DlgItems, 'BotText_'..i)
                               local Text=(aMenu[New].StrBuffer or {})[i] or '  '
                               if i == aMenu[New].Curl then
                                Text = SelSimb..Text
                               else
                                Text = ' '..Text
                               end
                               hDlg:send("DM_SETTEXT", iBotText, Text)
                              end
                             end;
              OnDialogInit = function(aaPar)
                              local DlgItems=aaPar[7]
                              tin(DlgItems,1,DialogItem{"DI_DOUBLEBOX", x1=0;y1=0;x2=aaPar[4]+2;y2=aaPar[5]+8;})
                              aaPar[4]=aaPar[4]+2 -- X2
                              aaPar[5]=aaPar[5]+9 -- Y2
                              local ListNo=FindByName(DlgItems, 'List')
                              DlgItems[ListNo][4] = DlgItems[ListNo][4] + 2
                              tin(DlgItems, DialogItem{"DI_TEXT";x1=1; y1=DlgItems[ListNo][5]+1; x2=aaPar[4]-aaPar[2]-5; Flags="DIF_SEPARATOR2|DIF_CENTERTEXT|DIF_CENTERGROUP"; Text="Предпросмотр"})
                              for i=1,7 do
                               tin(DlgItems,DialogItem{"DI_TEXT", x1=1;y1=DlgItems[ListNo][5]+i+1; x2=aaPar[4]-aaPar[2]-5; Flags="DIF_SHOWAMPERSAND"; Name='BotText_'..i})
                              end
                              return aaPar
                             end;
              Grouping=true
             }
 local function CheckStr(hDlg, _key, CurrPos, Source, DlgItems, lbItems)
  if Busy then return end
  local function _Not(Flags, xFlag)
   local Result
   if (type(Flags) == 'table' and type(xFlag) == 'string') then
    Result = Flags
    if Flags[xFlag] then Flags[xFlag] = nil
    else Flags[xFlag] = 1 end
   else
    Flags = FlagsToNumber(Flags)
    xFlag = FlagsToNumber(xFlag)
    Result = bxor(Flags, xFlag)
   end
   return Result
  end -- _Not
  local ListNo=FindByName(DlgItems, 'List')
  if lbItems[CurrPos].Separator then return true end
  Busy = true
  aMenu[CurrPos].checked = not aMenu[CurrPos].checked;
  ChkCount = ChkCount + (aMenu[CurrPos].checked and 1 or -1)
  lbItems[CurrPos].Flags = _Not(lbItems[CurrPos].Flags, "LIF_CHECKED")
  lbItems[CurrPos].Index = CurrPos
  local aCurr1=hDlg:send("DM_LISTGETCURPOS", ListNo)
  hDlg:send("DM_LISTUPDATE", ListNo, lbItems[CurrPos])
  if TestFarFlag(lbItems[CurrPos].Flags, "LIF_CHECKED") then
   -- Надо погасить другую строку из этого же файла
   local bDone=false
   for i=CurrPos-1,2,-1 do
    if lbItems[i].Separator then break end
    if TestFarFlag(lbItems[i].Flags, "LIF_CHECKED") then
     lbItems[i].Flags = _Not(lbItems[i].Flags, "LIF_CHECKED")
     lbItems[i].Index = i
     hDlg:send("DM_LISTUPDATE", ListNo, lbItems[i])
     aMenu[i].checked = false
     bDone = true
     ChkCount = ChkCount - 1
     break
    end
   end
   if not bDone then
    for i=CurrPos+1,#lbItems do
     if lbItems[i].Separator then break end
     if TestFarFlag(lbItems[i].Flags, "LIF_CHECKED") then
      lbItems[i].Flags = _Not(lbItems[i].Flags, "LIF_CHECKED")
      lbItems[i].Index = i
      hDlg:send("DM_LISTUPDATE", ListNo, lbItems[i])
      aMenu[i].checked = false
      ChkCount = ChkCount - 1
      break
     end
    end
   end
  end
  Props.Bottom = MenuBottom(ChkCount)
  hDlg:send("DM_LISTSETTITLES", ListNo, {Title=Props.Title; Bottom=Props.Bottom})
  hDlg:send("DM_LISTSETCURPOS", ListNo, aCurr1)
  Busy = false
  return true
 end -- CheckStr
 local function RemoveStr(hDlg, _key, iChoice, Source, DlgItems, lbItems)
  local ListNo=FindByName(DlgItems, 'List')
  local OldPos = hDlg:send("DM_LISTGETCURPOS", ListNo)
  if lbItems[iChoice].Separator then
   if far.Message(GetMsg("DelConfirm"):format(aMenu[iChoice].text), GetMsg"ScriptTitle", ';YesNo') == 1 then
    local i=iChoice+1
    while i <= #lbItems and not lbItems[i].Separator do
     table.remove(lbItems, i)
     table.remove(aMenu, i)
    end
    table.remove(lbItems, iChoice)
    table.remove(aMenu, iChoice)
   end
  else
   table.remove(aMenu, iChoice)
   table.remove(lbItems, iChoice)
   --if NewPos > #lbItems or lbItems[NewPos].Separator then NewPos = NewPos - 1 end
   if (iChoice > 1 and lbItems[iChoice-1].Separator) and
      (iChoice > #lbItems or lbItems[iChoice].Separator) then
    table.remove(aMenu, iChoice-1)
    table.remove(lbItems, iChoice-1)
    OldPos.SelectPos = math.min(OldPos.SelectPos, #lbItems)
   end
  end
  if #lbItems == 0 then
   hDlg:send("DM_CLOSE")
  else
   hDlg:send("DM_LISTSET", ListNo, lbItems)
   if OldPos.SelectPos > #lbItems then OldPos.SelectPos = #lbItems end
   hDlg:send("DM_LISTSETCURPOS", ListNo, OldPos)
  end
  return true
 end -- RemoveStr
 local BreakKeys={ { BreakKey='AltF4';
                     Action=function(hDlg, _key, iChoice, Source, DlgItems, lbItems)
                      if not lbItems[iChoice].Separator then
                       editor.Editor(aMenu[iChoice].fn, nil, nil, nil, nil, nil, FlagsToNumber('EF_LOCKED|EF_OPENMODE_NEWIFOPEN'), aMenu[iChoice].iL)
                      end
                      return true
                     end
                   };
                   { BreakKey='F4';
                     Action=function(hDlg, _key, iChoice, Source, DlgItems, lbItems)
                      if not lbItems[iChoice].Separator then
                       editor.Editor(aMenu[iChoice].fn, nil, nil, nil, nil, nil, FlagsToNumber('EF_LOCKED|EF_OPENMODE_NEWIFOPEN'), aMenu[iChoice].iL)
                      end
                      return true
                     end
                   };
                   { BreakKey='F8'; Action=RemoveStr };
                   { BreakKey='Del'; Action=RemoveStr };
                   { BreakKey='Ins'; Action=CheckStr; };
                   { BreakKey='Space'; Action=CheckStr; };
                 }
 local _, iChoice=far_Menu(Props, aMenu, BreakKeys)
 if iChoice and (iChoice > 0) and (iChoice <= #aMenu) then
  if ChkCount == 0 then
   editor.Editor(aMenu[iChoice].fn, nil, nil, nil, nil, nil, FlagsToNumber('EF_NONMODAL|EF_IMMEDIATERETURN|EF_ENABLE_F6|EF_OPENMODE_NEWIFOPEN'), aMenu[iChoice].iL)
  else
   for _,v in ipairs(aMenu) do
    if v.checked then
     editor.Editor(v.fn, nil, nil, nil, nil, nil, FlagsToNumber('EF_NONMODAL|EF_IMMEDIATERETURN|EF_ENABLE_F6|EF_OPENMODE_NEWIFOPEN'), v.iL)
    end
   end
  end
 end
end -- Find_n_Go

Macro{
--  id="";
  --area="Shell Editor"; -- В редаторе CtrlShiftF7 - проверка синтаксиса lua
  area="Shell"; -- Menu Tree Dialog Disks  Editor Grabber FindFolder Desktop UserMenu DialogAutoCompletion Search ShellAutoCompletion MainMenu Info Other Help QView Viewer
  key="CtrlShiftF7";
  description="BAX: Поиск по файлам с переходом на строку";
--  filemask="";
  flags=""; -- DisableOutput RunAfterFARStart EmptyCommandLine NotEmptyCommandLine NoFilePanels NoFilePPanels NoPluginPanels NoPluginPPanels NoFolders NoPFolders NoFiles NoPFiles Selection PSelection NoSelection NoPSelection EVSelection NoEVSelection NoSendKeysToPlugins
--  priority=50;
--  sortpriority=50;
--  condition=function(key) return true end;
  action=function()
   local aPar=Dialog_Exec()
   if aPar then
    Find_n_Go(aPar)
   end
  end;
}
