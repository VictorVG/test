--local TabUtils=require"Bax.TabUtils"
--local TabToStr=TabUtils.TableToString

local C = far.Colors
local F=far.Flags
--------------------------------------------------------------------------------------------------
local BAX_Round, far_InputBox, far_InputForm, far_Menu, CopyFileEx_Lua, class_ProgressBar, class_ShowMessage,
      SparseIntToStr, MergeSettings, ANSItoUTF_8, UTF_8ToANSI, RemDir, ChoiceSubFolder, FindOneFile, TestFarFlag,
      FlagsToNumber, DialogItem, DialogItemVal, SplitBySpace
--------------------------------------------------------------------------------------------------

local class_def

do

 local class_metatable = {}

 function class_metatable.__call(class, ...)
    local obj = setmetatable({}, class)

    if class.__init then
       class.__init(obj, ...)
    end

    return obj
 end

 function class_def()
    local class = setmetatable({}, class_metatable)
    class.__index = class
    return class
 end

end

local ffi = require("ffi")


-- Формрование строки отображения целого с разделением на группы
SparseIntToStr = function (n,g,c,w)
  -- n - выводимое число (целое)
  -- g - количество цифр в группе (по умолчанию - 3)
  -- c - символ-наполнитель (по умолчанию - chr(160))
  -- w - минимальная ширина числа. Отрицательное - прижато к левому краю
  g = g or 3
  c = c or mf.chr(160)

  local s=tostring(n)
  for i=s:len()-g+1,2,-g do
    s=s:sub(1,i-1)..c..s:sub(i)
  end
  if w then
   s = mf.strpad(s, mf.abs(w),' ', w<0 and 0 or 1)
  end
  return s
end

BAX_Round = function (v,c) -- v - значение; c - точность
 return c and (math.floor(v*c +.5) / c) or (math.floor(v +.5) )
end

far_InputBox = function (tbData)
 return far.InputBox(tbData.Id, tbData.Title, tbData.Prompt,
                     tbData.HistoryName or tbData.History,
                     tbData.SrcText or tbData.Data,
                     tbData.DestLength, tbData.HelpTopic, FlagsToNumber(tbData.Flags) )
end

far_InputForm = function (tbData)
 local lResult=false
 local h,w,iH,nI,n
 local aDial={}
 local iChoice
 -- Расчёт координат
 if type(tbData.Prompts) == 'table' and
    type(tbData.Data) == 'table' then
  n = math.max(#tbData.Prompts, #tbData.Data)
  w = 0
  for i=1,n do
   --Good! w = math.max( w, (tbData.Prompts[i] or (' '):rep(10)):len() + math.max((tbData.Data[i] or (' '):rep(10)):len(), (tbData.DataLen or 0)) )
   w = math.max( w, (tbData.Prompts[i] or ''):len() + math.max((tbData.Data[i] or ''):len(), (tbData.DataLen or 0)) )
  end
  --for _,v in ipairs(tbData.Prompts) do
  -- w = math.max(w, v:len())
  --end
  iChoice = 1
 elseif type(tbData.Items) == 'table' then
  n = #tbData.Items
  w = 0
  for _,v in ipairs(tbData.Items) do
   w = math.max( w, v.Prompt:len() + math.max(v.Text:len(),(tbData.DataLen or 0)) )
  end
  iChoice = 2
 end
 w = math.max(math.floor(Far.Width / 4), math.min(w+10, Far.Width-3))
 h = math.min(Far.Height-3, n*2+5)
 iH = 2
 nI = 3
 if tbData.Caption and tbData.Title then
  h = h + 1
 end
 aDial[#aDial+1] = {"DI_DOUBLEBOX", 0,0,w,h,0,0,0,0, tbData.Caption or tbData.Title}
 if tbData.Caption and tbData.Title then
  aDial[#aDial+1] = {"DI_TEXT", 1, iH-1, w-3, iH, 0, 0, 0, 'DIF_CENTERTEXT', tbData.Title}
  iH = iH + 1
  nI = nI+ 1
 end
 if iChoice == 1 then
  for i=1,n do
   aDial[#aDial+1] = {"DI_TEXT", 3, iH, w-15, iH+1, 0,0,0,{DIF_WORDWRAP=1}, tbData.Prompts[i] or ''}
   aDial[#aDial+1] = {"DI_EDIT", math.min(tbData.Prompts[i]:len()+5, w-13), iH, w-4, iH, 0,0,0,0, tbData.Data[i]}
   iH = iH + 2
  end
 else
  for _,v in ipairs(tbData.Items) do
   aDial[#aDial+1] = {"DI_TEXT", 3, iH, w-15, iH+1, 0,0,0,{DIF_WORDWRAP=1}, v.Prompt}
   aDial[#aDial+1] = {"DI_EDIT", math.min(v.Prompt:len()+5, w-13), iH, w-4, iH, 0,0,0,0, v.Text}
   iH = iH + 2
  end
 end
 aDial[#aDial+1] = {"DI_BUTTON", 0,iH, 0, 0, 0,0,0,{DIF_CENTERGROUP=1;DIF_DEFAULTBUTTON=1}, 'Ok'}
 aDial[#aDial+1] = {"DI_BUTTON", 0,iH, 0, 0, 0,0,0,{DIF_CENTERGROUP=1;}, 'Cancel'}
 local h0=math.floor((Far.Height-h) / 2)
 local w0=math.floor((Far.Width-w) / 2)+1
 if far.Dialog(win.Uuid(), w0,h0,w+w0-2,h+h0-2,nil,aDial) == #aDial-1 then
  lResult = true
  if iChoice == 1 then
   iH = nI
   tbData.Result = {}
   for i=1,n do
    tbData.Result[i] = aDial[iH][10]
    iH = iH + 2
   end
  else
   iH = nI
   for _,v in ipairs(tbData.Items) do
    v.Text = aDial[iH][10]
    iH = iH + 2
   end
  end
 end
 return lResult
end

MergeSettings = function (Old, New)
 if type(New) == 'function' then
  local _
  _, New = pcall(New)
 end
 if type(New) == 'table' then
  for i,v in pairs(New) do
   Old[i]=v
  end
 end
 return Old
end

local MenuColorIndex = {
  C.COL_MENUTEXT,             -- подложка
  C.COL_MENUBOX,              -- рамка
  C.COL_MENUTITLE,            -- заголовок - верхний и нижний
  C.COL_MENUTEXT,             -- Текст пункта
  C.COL_MENUHIGHLIGHT,        -- HotKey
  C.COL_MENUTEXT,             -- separator
  C.COL_MENUSELECTEDTEXT,     -- Выбранный
  C.COL_MENUSELECTEDHIGHLIGHT,-- Выбранный - HotKey
  C.COL_MENUSCROLLBAR,        -- ScrollBar
  C.COL_MENUDISABLEDTEXT,     -- Disabled
  C.COL_MENUARROWS,           -- '<' & '>' обычные
  C.COL_MENUARROWSSELECTED,   -- '<' & '>' выбранные
  C.COL_MENUARROWSDISABLED,   -- '<' & '>' Disabled
  C.COL_MENUGRAYTEXT,         -- "серый"
  C.COL_MENUSELECTEDGRAYTEXT, -- выбранный "серый" -- 15
}

local MenuPalette = {}
--for i,v in ipairs(MenuColorIndex) do MenuPalette[i] = v and far.AdvControl(F.ACTL_GETCOLOR,v) end
for i,v in ipairs(MenuColorIndex) do MenuPalette[i] = far.AdvControl(F.ACTL_GETCOLOR,v) end
local DialogPalette = {far.AdvControl(F.ACTL_GETCOLOR,C.COL_MENUTITLE),
                       far.AdvControl(F.ACTL_GETCOLOR,C.COL_MENUTEXT),
                       far.AdvControl(F.ACTL_GETCOLOR,C.COL_MENUBOX),
                       nil
                      }

-- Реализация far.Menu (или Menu.Show) через диалог.
-- Отличия от указанных:
--   1. Объединение функций:
--     1.1. Даёт возможность в отличие от far.Menu установить "Начальный фильтр", а от Menu.Show - BreakKeys
--     1.2. Items может быть и строкой (как в Menu.Show), так и таблицей (как в far.Menu);
--     1.3. Добавлено ограничение по ширине (Properties.MaxWidth). Ограничение по высоте
--          (Properties.MaxHeight) есть в стандартном far.Menu
--   2. Расширение функционала:
--     2.1. BreakKeys может быть регэкспом. (обрамлён слэшами. стандартный - не LUA - регэксп)
--     2.2. Фильтр также может быть регэкспом.
--     2.3. Фильтрация может быть регистрозависимой
--     2.4. Если BreakKeys - таблица, то в каждом элементе можно указать
--          Action=function(hDlg, _key, CurrPos, lbItems[CurrPos].Source, DlgItems, lbItems)
--          DlgItems можно использовать для передачи BreakKey в вызывающую процедуру
--          (присвоить DlgItems.BreakKey=<то, что надо>. Например, {BreakKey=_key; RealResult='qqq'})
--     2.5. Начальный фильтр может быть строкой (конечные слэши включают режим регэкспа), функцией
--          (на входе - строка: на выходе - boolean) или таблицей - списком строк.
--     2.6. Добавлена возможность указывать максимальную ширину (вдобавок к максимальной высоте) (Properties.MaxWidth)

--     2.7. Добавлена возможность задания обработчика события DN_LISTCHANGE (Properties.OnListChange).
--          В обработчик передаются: хендлер диалога, номер элемента-списка, старое и новое положения
--          указателя, массив элементов диалога
--     2.8. Добавлена возможность указать процедуру инициализации диалога (в т.ч. добавления элементов).
--          Указывается в Poperties.OnDialogInit
--     2.9. Добавлена возможность задать свой обработчик событий (параметр Properties.UserDlgHandler).
--          Параметры те же плюс список элементов диалога. Возвращает два значения: Done - отработал
--          ли UserDlgHandler и возвращаемое значение.
--   3. Не реализовано:
--     3.1. Указание символа для checked-строк
local _MenuFlagsToDialogFlags = {
     'checked',
     --'separator',
     'disable', 'grayed', 'hidden', 'selected'
}
far_Menu = function(Properties, Items, BreakKeys)
 local tin=table.insert
 local function FindByName(DlgItems, Name)
  for i,v in ipairs(DlgItems) do
   if v.Name and v.Name==Name then return i end
  end
 end
 if type(Items) == 'string' then
  local s=Items
  Items = {}
  for w in s:gmatch('[^\n]+') do
   if w:sub(1,1) == '\1' or w:sub(1,1) == '\2' then
    Items[#Items+1]={text=w:sub(2); separator=true}
   else
    Items[#Items+1]={text=w}
   end
  end
 end
 if not Properties then Properties={} end
 local FiltRegExp, FiltCaseSens, FiltFromBeg, Title, Bottom, AutoNum, AutoAccel, FilterStr=
       Properties.RegExp, Properties.CaseSensitive, Properties.FromBegin, Properties.Title, Properties.Bottom,
       Properties.AutoNum, Properties.AutoAccel, Properties.FilterStr
 AutoAccel = false
 local DlgItems, ListNo, FiltTextId={}
 local w, h=math.max( (Title or ''):len(), (Bottom or ''):len() ), 0
 local lbItems = {}
 for _,v in ipairs(Items) do
  w = math.max(w, v.text:len()+2)
  h = h + 1
  lbItems[h] = {Text=v.text; Flags={}, Hidden = v.Hidden; Source=v.text}
  if v.separator then
   if Properties.Grouping then
    lbItems[h].Separator = true
    lbItems[h].Collapsed = false
   else
    lbItems[h].Flags.LIF_SEPARATOR = 1
   end
  end

  for i,vv in ipairs(_MenuFlagsToDialogFlags) do
   if v[vv] then
    lbItems[h].Flags['LIF_'..vv:upper()] = type(v[vv]) == 'boolean' and 1 or v[vv]
   end
  end
  if v.Hidden then
   lbItems[h].Flags.LIF_HIDDEN=1
  end
 end -- for _,v in ipairs(Items) do
 for _,v in ipairs(lbItems) do
  if v.Separator then v.Text = (v.Collapsed and '+ ' or '- ') .. mf.strpad(' '..v.Text..' ', w-2, '─', 2) end
 end
 -- Автонумерация
 if AutoNum then
  local iNum, Fmt=0,'%'..tostring(#lbItems):len()..'d - %s'
  for _,v in ipairs(lbItems) do
   if not (v.Flags.LIF_HIDDEN or v.Flags.LIF_SEPARATOR or v.Flags.LIF_DISABLE) then
    iNum = iNum + 1
    v.Text = Fmt:format(iNum, v.Source)
   end
  end
  w = w + tostring(#lbItems):len() + 3
 end
 -- Автопроставление акселераторов
 if AutoAccel then
  local aAccel, cAccel=''
  for _,v in ipairs(lbItems) do
   local sItem=v.Text
   for i=1,sItem:len() do
    cAccel = sItem:sub(i,i)
    if cAccel:match('[%w_]') and
       not aAccel:find(cAccel,1,true) then
     v.Text = v.Text:sub(1,i-1)..'&'..v.Text:sub(i)
     aAccel = aAccel .. cAccel
     break
    end
   end
  end
 end
 local sFilter
 local function _ApplyFilter(hDlg, Id)
  local _hidden, sItem
  if type(sFilter) == 'string' and not FiltCaseSens then sFilter = sFilter:upper() end
  for i,v in ipairs(lbItems) do
   sItem = v.Source
   if not FiltCaseSens then sItem = sItem:upper() end
   if not v.Hidden -- Перманентное сокрытие. Фильтру неподвластно
      and not v.Flags.LIF_SEPARATOR then
   if sFilter == '' then
    _hidden = false
   else
     if type(FilterStr) == 'string' then
      if FiltRegExp then
       _hidden = (regex.match(sItem, (FiltFromBeg and '^' or '') .. sFilter) == nil)
      else
       _hidden = FiltFromBeg and
                   (mf.index(sItem, sFilter, FiltCaseSens and 1 or 0) ~= 0) or
                   (mf.index(sItem, sFilter, FiltCaseSens and 1 or 0) < 0)
      end
     elseif type(FilterStr) == 'function' then
      _hidden = not FilterStr(v)
     elseif type(FilterStr) == 'table' then
      _hidden = true
      for _,vv in ipairs(FilterStr) do
       sFilter = vv
       if not FiltCaseSens then sFilter=sFilter:upper() end
       if sFilter:match('^/.*/$') then
        _hidden = not regex.match( sItem, sFilter:match('^/(.*)/$') )
       else
        _hidden = FiltFromBeg and
                    (mf.index(sItem, sFilter, FiltCaseSens and 1 or 0) == 0) or
                    (mf.index(sItem, sFilter, FiltCaseSens and 1 or 0) >= 0)
       end
       if not _hidden then break end
      end
     end
    end
    _hidden = _hidden and 1 or nil
    if lbItems[i].Flags.LIF_HIDDEN ~= _hidden then
     lbItems[i].Flags.LIF_HIDDEN = _hidden
     if hDlg then
      hDlg:send(F.DM_LISTUPDATE, Id, {Index=i, Text= lbItems[i].Text, Flags=lbItems[i].Flags})
     end
    end
   end -- if not v.Hidden
  end -- for i,v in ipairs(lbItems)
  -- Скрытие разделителей, после которых нет видимых пунктов
  local iSep
  iSep, _hidden = 0, true
  for i,v in ipairs(lbItems) do
   if v.Flags.LIF_SEPARATOR then
    if iSep > 0 then
     lbItems[iSep].Flags.LIF_HIDDEN = _hidden and 1 or nil
     if hDlg then
      hDlg:send(F.DM_LISTUPDATE, Id, {Index=iSep, Text= lbItems[iSep].Text, Flags=lbItems[iSep].Flags})
     end
    end
    iSep, _hidden = i, true
   elseif not v.Flags.LIF_HIDDEN then
    _hidden = false
   end
  end
  if iSep > 0 then
   lbItems[iSep].Flags.LIF_HIDDEN = _hidden and 1 or nil
   if hDlg then
    hDlg:send(F.DM_LISTUPDATE, Id, {Index=iSep, Text= lbItems[iSep].Text, Flags=lbItems[iSep].Flags})
   end
  end
  if hDlg then
   if sFilter == '' then
    hDlg:send("DM_SETTEXT", FiltTextId, "")
   else
    hDlg:send("DM_SETTEXT", FiltTextId, "["..sFilter..']')
   end
  end
 end -- _ApplyFilter
 -- Применение начального фильтра
 sFilter = FilterStr or ''
 _ApplyFilter()
 w = math.min(w + 2, Properties.MaxWidth or Far.Width)
 h = math.min(h + 3, math.floor(Properties.MaxHeight or APanel.Height * 0.75) )-- Ограничиваю высоту 3/4 от высоты панели
 tin(DlgItems, DialogItem{"DI_TEXT",1,1,w-1,0,0,0,0,{DIF_CENTERTEXT=1}, sFilter=='' and '' or '['..sFilter..']'; Name='FiltText'});
 tin(DlgItems, DialogItem{"DI_LISTBOX"; x1=0; y1=0; x2=w,y2=h; ListItems=lbItems; Name='List';});
 local X1,Y1 = Properties.X or BAX_Round((Far.Width - w) / 2),Properties.Y or math.floor( (APanel.Height - h) / 2)
 local function _DlgProc(hDlg, Msg, ItemId, Param2)
  if Properties.UserDlgHandler then
   local Done, Res = Properties.UserDlgHandler(hDlg, Msg, ItemId, Param2, DlgItems)
   if Done then
    return Res
   end
  end
  local cont=true
  while cont do
   cont = false
   if Msg == F.DN_INITDIALOG then
    if Properties.Title or Properties.Bottom then
     hDlg:send("DM_LISTSETTITLES", ListNo, {Title=Title or 'Эмулятор Меню'; Bottom=Properties.Bottom})
    end
    if Properties.SelectIndex or Properties.Grouping then
     local iIndex=Properties.SelectIndex or 1
     if Properties.Grouping then
      for i=iIndex, #lbItems-1 do
       if not lbItems[i].Separator then iIndex = i; break end
      end
      if lbItems[iIndex].Separator then
       for i=iIndex, 1, -1 do
        if not lbItems[i].Separator then iIndex = i; break end
       end
      end
     end
     hDlg:send("DM_LISTSETCURPOS", ListNo, {SelectPos=iIndex})
    end;
    if Properties.OnListChange then
     local Ind=Properties.SelectIndex or 1
     Properties.OnListChange(hDlg, ListNo, 0, Ind, DlgItems)
    end
   --elseif Msg == F.DN_DRAWDIALOGDONE and
   --       Properties.OnListChange then
   -- local Ind=hDlg:send("DM_LISTGETCURPOS", ListNo).SelectPos
   -- Properties.OnListChange(hDlg, ListNo, 0, Ind, DlgItems)
   elseif Msg == F.DN_CTLCOLORDLGLIST then
    return MenuPalette
   elseif Msg == F.DN_CTLCOLORDLGITEM then
    if DlgItems[ItemId][1] == 'DI_DOUBLEBOX' or
       DlgItems[ItemId][1] == 'DI_TEXT' then
     return DialogPalette
    end
   elseif Msg == F.DN_CTLCOLORDIALOG then
    return far.AdvControl(F.ACTL_GETCOLOR,C.COL_MENUTEXT)
   elseif (Msg == F.DN_LISTHOTKEY) then
    mf.postmacro(Keys, "Enter")
   elseif Msg == F.DN_CONTROLINPUT and
          Param2.EventType == F.KEY_EVENT then
    local _key=far.InputRecordToName(Param2)
    local aCurrPos=hDlg:send("DM_LISTGETCURPOS", ListNo)
    local CurrPos=aCurrPos.SelectPos
    if ( _key == 'Enter' ) and
       ( (type(lbItems[CurrPos].Action) == 'function') or
         ( (Properties.Grouping) and (lbItems[CurrPos].Separator) )
       )
    then
     if type(lbItems[CurrPos].Action) == 'function' then
      lbItems[CurrPos].Action(hDlg, _key, CurrPos, lbItems[CurrPos].Source, DlgItems, lbItems)
     end
     if (Properties.Grouping) and (lbItems[CurrPos].Separator) then
      lbItems[CurrPos].Collapsed = not lbItems[CurrPos].Collapsed
      lbItems[CurrPos].Text = (lbItems[CurrPos].Collapsed and '+' or '-') .. lbItems[CurrPos].Text:sub(2)
      --if lbItems[CurrPos].Collapsed then
       for i=CurrPos+1,#lbItems do
        if lbItems[i].Separator then break end
        if lbItems[i].Flags.LIF_HIDDEN then lbItems[i].Flags.LIF_HIDDEN = nil
        else lbItems[i].Flags.LIF_HIDDEN = 1 end
       end
      --end
      hDlg:send("DM_LISTSET", ListNo, lbItems)
     end
     hDlg:send("DM_LISTSETCURPOS", ListNo, aCurrPos)
     return true
    end
    if BreakKeys then
     local _BreakKeys, _BreakKey
     if type(BreakKeys) == 'string' then
      _BreakKeys = {{BreakKey=BreakKeys}}
     else
      _BreakKeys = BreakKeys
     end
     for _,v in ipairs(_BreakKeys) do
      -- Строка; возможно, регэксп
      _BreakKey = v.BreakKey
      if _BreakKey:match('^/.*/') then
       -- Регэксп
       if regex.match(_key, _BreakKey:match('^/(.*)/$')) then
        if type(v.Action) == 'function' then
         v.Action(hDlg, _key, CurrPos,
                  lbItems[CurrPos].Source,
                  DlgItems, lbItems)
        else
         DlgItems.BreakKey = {BreakKey=_key}
         hDlg:send"DM_CLOSE"
         return
        end
       end
      --elseif _BreakKey:match('^f/.*/') then
      -- if _key:match(_BreakKey:match('^f/(.*)/$')) then
      --  DlgItems.BreakKey = {BreakKey=_key}
      --  hDlg:send"DM_CLOSE"
      --  return
      -- end
      else
       -- Список клавиш
       if (' '.._BreakKey..' '):find(_key, 1, true) then
        if type(v.Action) == 'function' then
         local Done, Result=v.Action(hDlg, _key, CurrPos, lbItems[CurrPos].Source, DlgItems, lbItems)
         if Done then
          return Result
         end
        end
        DlgItems.BreakKey = {BreakKey=_key}
        hDlg:send"DM_CLOSE"
        return
       end
      end -- регэксп/не регэксп
     end -- for _,v in ipairs(_BreakKeys)
    end -- if BreakKeys
    -- Сюда попадаем, если BreakKey не найден
    if regex.match(_key, '^([\\w_]|Space)$') and
       type(sFilter) == 'string' then
     if _key=='Space' then _key = ' ' end
     sFilter = (sFilter or '') .. (FiltCaseSens and _key or _key:upper())
     _ApplyFilter(hDlg, ListNo)
    elseif (_key == 'BS') then --and sFilter:len() > 1 then
     sFilter = sFilter:sub(1,sFilter:len()-1)
     _ApplyFilter(hDlg, ListNo)
    end
   elseif Msg == F.DN_CONTROLINPUT and
          Param2.EventType == F.MOUSE_EVENT
      and (band(Param2.ButtonState, F.FROM_LEFT_1ST_BUTTON_PRESSED) == F.FROM_LEFT_1ST_BUTTON_PRESSED)
      and (band(Param2.ControlKeyState, bor(F.RIGHT_ALT_PRESSED, F.LEFT_ALT_PRESSED, F.RIGHT_CTRL_PRESSED, F.LEFT_CTRL_PRESSED, F.SHIFT_PRESSED)) == 0)
      and (band(Param2.EventFlags, F.DOUBLE_CLICK) == F.DOUBLE_CLICK) then
    Param2 = far.NameToInputRecord('Enter')
    cont = true
   elseif Msg == F.DN_HELP then
    if Properties.HelpFile and Properties.HelpTopic then
     far.ShowHelp(Properties.HelpFile, Properties.HelpTopic, 'FHELP_CUSTOMFILE')
     return ''
    end
   elseif Msg == F.DN_LISTCHANGE then
    if Properties.OnListChange then
     return Properties.OnListChange(hDlg, ItemId, hDlg:send("DM_LISTGETCURPOS", ItemId).SelectPos, Param2, DlgItems)
    end
   end -- if Msg
  end -- while cont
 end -- _DlgProc
 local DlgParams = {
                 '',                    -- 1 Guid
                 X1,                    -- 2 X1
                 Y1,                    -- 3 Y1
                 X1+w, Y1+h,            -- 4,5 - X2, Y2
                 Properties.HelpTopic,
                 DlgItems,
                 "FDLG_SMALLDIALOG",
                 _DlgProc
                   }
 if Properties.OnDialogInit then
  DlgParams = Properties.OnDialogInit(DlgParams);
 end
 ListNo=FindByName(DlgItems, 'List')
 FiltTextId=FindByName(DlgItems, 'FiltText')
 local res= far.Dialog(unpack(DlgParams))
     --far.Dialog(
     --            '',                    -- 1 Guid
     --            X1,                    -- 2 X1
     --            Y1,                    -- 3 Y1
     --            X1+w, Y1+h,            -- 4,5 - X2, Y2
     --            Properties.HelpTopic,
     --            DlgItems,
     --            "FDLG_SMALLDIALOG",
     --            _DlgProc
     --          )
 if res and res > 0 then
  if DlgItems.BreakKey then
   return DlgItems.BreakKey,lbItems.SelectIndex
  else
   return Items[lbItems.SelectIndex],lbItems.SelectIndex
  end
 end
end -- far_Menu

------------------------ ShowProgress ------------------------
class_ProgressBar=class_def()


function class_ProgressBar:__init()
  self.iTime = 0
  self.cntr = true
  self.CurrPos = 0
  self.cntb = 0
  self.Width = BAX_Round(Far.Width / 2)
  self.minValue = 0
  self.maxValue = 100
  --self.iTimeInterval =
end

function class_ProgressBar:Step(iPercent)
  if self.iTimeInterval == nil then
   self.iTimeInterval = (iPercent and 500 or 20)
    -- Чтоб не чаще чем 2 раза в секунду - если градусник и не чаще чем 50 раз в секунду - если бесконечный индикатор
  end
  if (not self.iTime) or (self.iTime == 0) then
    self.iTime = win.GetSystemTimeAsFileTime()
  elseif os.difftime(win.GetSystemTimeAsFileTime(), self.iTime) < self.iTimeInterval then
    return
  end
  local progressbar
  if iPercent == nil then
    -- "Туда-сюда индикатор"
    if self.cntr then
      -- Растёт правый конец
      self.CurrPos = self.CurrPos + 1
      progressbar = ('█'):rep(self.CurrPos) .. ('░'):rep(self.Width-self.CurrPos)
      if self.CurrPos == self.Width then
        -- Достигнут конец
        self.cntr = false -- в следующий раз убираю слева
      end
    else
      -- "убирается" левый конец
      self.cntb = self.cntb + 1
      progressbar = ('░'):rep(self.cntb) .. ('█'):rep(self.Width-self.cntb)
      if self.cntb == self.Width then
        self.cntb, self.CurrPos, self.cntr = 0,0,true
      end
    end
  else
    -- "Градусник"
    self.CurrPos = BAX_Round(iPercent / (self.maxValue-self.minValue) * self.Width )
    progressbar = ('█'):rep(self.CurrPos) ..  ('░'):rep(self.Width-self.CurrPos)
  end
  self.iTime = win.GetSystemTimeAsFileTime()
  return progressbar
end -- class_ProgressBar:Step


class_ShowMessage = class_def()

function class_ShowMessage:__init(Title, Strings, color, margins, delayed)
  self.Title = Title
  self.Strings = Strings or {}
  self.color = color or far.AdvControl("ACTL_GETCOLOR",C.COL_DIALOGTEXT)
  self.margins = margins or 2
  self.delayed = (type(delayed)=='boolean' and delayed or false)
end

local pad=mf.strpad

function class_ShowMessage:Line(idx, bDelay)
  if self.LastPos then
    local w, y0, x = self.LastPos.Width, self.LastPos.Top, self.LastPos.Left
    if (idx and idx <= #self.Strings) and (w and w > 0 ) and (x and x > 0) then
      if self.Strings[idx]:len() <= w then
         far.Text(x+2+self.margins, y0 + (self.Title and 1 or 0) + idx , self.color, pad(self.Strings[idx], w-4, ' ', 2))
         if not bDelay then far.Text() end
         return
      end
    end
  end
  self:Show(nil, bDelay)
end

function class_ShowMessage:Show(Strings, bDelay)
  if Strings then
    self.Strings = Strings
  end
  if type(bDelay) ~= 'boolean' then bDelay = self.delayed end
  local h = #self.Strings + 2
  if self.Title then h = h + 1 end
  local w = self.Title and self.Title:len()+2 or 0
  for _,v in ipairs(self.Strings) do
   if v ~= '\1' and v ~= '\2' then
    w = math.max(w,v:len()+4)
   end
  end
  local x=BAX_Round( (Far.Width-w-2*self.margins)/2 )
  local y=BAX_Round( (APanel.Height-h)/2 ) - 1
  local y0=y
  self.LastPos = {Top = y0; Width = w; Left = x}
  w = w + 2*self.margins
  if self.Title then
   far.Text(x,y,self.color,pad(self.Title, w, ' ', 2)); y=y+1
  end
  far.Text(x,y,self.color,' ╔'..('═'):rep(w-4)..'╗ '); y=y+1

  for _,v in ipairs(self.Strings) do
   if v == '\1' then
    far.Text(x,y,self.color, ' ╟'..('─'):rep(w-4)..'╢ ')
   elseif v == '\2' then
    far.Text(x,y,self.color, ' ╠'..('═'):rep(w-4)..'╣ ')
   else
    far.Text(x,y,self.color, ' ║'..pad(v,w-4,' ',2)..'║ ')
   end
   y=y+1
  end
  far.Text(x,y,self.color,' ╚'..('═'):rep(w-4)..'╝ ')
  if not bDelay then far.Text() end
end -- class_ShowMessage:Show

--ShowMessage = class_ShowMessage()

CopyFileEx_Lua = function (inPath, outPath, sRewrite, bQuiet, TotalStart, TotalCount, tTotalStart)
  local lResult, resRewrite=false,nil
  if not mf.fexist(inPath) then
    if not bQuiet then far.Message(inPath..'\n\1\nИсходный файл не найден','CopyFileEx_Lua',nil,'w') end
    return lResult, resRewrite
  end

  local function _DirExist(cPath)
   return (win.GetFileAttr(cPath) or ''):find('d')
  end

  if not _DirExist(mf.fsplit(outPath, 3)) then

    local _Res, sWhy  = win.CreateDir(mf.fsplit(outPath, 3))
    if not _Res then
      if type(sWhy) == 'string' then sWhy = mf.trim(sWhy) end -- Сообщение заканчивается \r. Убираю.
      if not bQuiet then
        far.Message('Неудача создания результирующего каталога\n'..mf.fsplit(outPath, 3)..'\n'..sWhy,'CopyFileEx_Lua',nil,'w')
      end
      return false, sWhy
    end
  elseif mf.fexist(outPath) then
    sRewrite = (sRewrite or ''):lower()
    if (sRewrite == '') then
      if bQuiet then
        sRewrite = 'skip'
      else
        local ans = far.Message(outPath..'\n\1\nФайл сужествует.\nЧто делать?','CopyFileEx_Lua','Переписать;Переименовать;Пропустить')
        if ans == 1 then
          sRewrite = 'rewrite'
        elseif ans == 2 then
          sRewrite = 'rename'
        else
          sRewrite = 'skip'
        end
      end
    end
    if sRewrite == 'skip' then
      resRewrite = sRewrite
      return lResult, resRewrite
    end
    if sRewrite == 'rename' then
      resRewrite = sRewrite
      local i=1
      local _outPath = mf.fsplit(outPath, 7) .. ' ('..i..')'..mf.fsplit(outPath, 8)
      while mf.fexist(_outPath) do i = i + 1 end
      outPath = _outPath
    end
  end


  -- Далее вместо стандартного типа LARGE_INTEGER используется LONGLONG, т.к.
  -- при использовании LARGE_INTEGER (union) возникала ошибка в вызове ffi.cast
  ffi.cdef[[
  typedef DWORD (__stdcall *LPPROGRESS_ROUTINE)(
                        LONGLONG TotalFileSize
                       ,LONGLONG TotalBytesTransferred
                       ,LONGLONG StreamSize
                       ,LONGLONG StreamBytesTransferred
                       ,DWORD         dwStreamNumber
                       ,DWORD         dwCallbackReason
                       ,HANDLE        hSourceFile
                       ,HANDLE        hDestinationFile
                       ,LPVOID        lpData
                     );

  BOOL CopyFileExW(
    LPCWSTR lpExistingFileName,
    LPCWSTR lpNewFileName,
    LPPROGRESS_ROUTINE lpProgressRoutine,
    LPVOID lpData,
    LPBOOL pbCancel,
    DWORD dwCopyFlags
  );

  ]]
  -------------------------------------------------------------------------------------------------
  local pbCancel = ffi.new("BOOL[1]"); pbCancel[0] = 0

  -------------------------------------------------------------------------------------------------

  local nTotFSize
  local tStart, tLast=0,0
  local Strings=
            {'', -- inPath                        -- 1
             '=>',                                -- 2
             '', -- outPath                       -- 3
             '\1',                                -- 4
             '', -- progressbar                   -- 5
             '', -- perents                       -- 6
             '', -- Прошло ... осталось скорость  -- 7
             '[Esc] - прервать'                   -- 8
            };

  local ProgressBar = class_ProgressBar()
  local TotProgress=nil
  if ( type(TotalStart) == 'number')  and ( (TotalCount or 0) > 0) then
    TotProgress = class_ProgressBar()
    TotProgress.CurrPos = TotalStart
    TotProgress.maxValue = TotalCount
    Strings[#Strings+1] = '\1'  -- 9
    Strings[#Strings+1] = ''    -- 10 TotProgress
    Strings[#Strings+1] = ''    -- 11 TotCount
    Strings[#Strings+1] = ''    -- 12 TotalTime
  end
  local ShowMessage = class_ShowMessage("Копирование файла...",
                                        Strings, -- Strings
                                        nil,     -- color  far.AdvControl("ACTL_GETCOLOR",C.COL_MENUTEXT),
                                        2,       -- margins
                                        true)    -- delayed

  local cbfc = ffi.cast("LPPROGRESS_ROUTINE", function(
                                         TotalFileSize
                                        ,TotalBytesTransferred
                                        ,StreamSize
                                        ,StreamBytesTransferred
                                        ,dwStreamNumber
                                        ,dwCallbackReason
                                        ,hSourceFile
                                        ,hDestinationFile
                                        ,lpData
                                       )
    local tNow = Far.UpTime
    if (tLast > 0) and ( (tNow-tLast) < 500 ) then return 0 end
    tLast = tNow
    local nBytesTransferred = tonumber(TotalBytesTransferred)
    local percents = BAX_Round( nBytesTransferred * 100 / nTotFSize )
    local PrBar=ProgressBar:Step(
                     --percents
                     nBytesTransferred
                    )
    if PrBar then
      ShowMessage.Strings[5] = PrBar
      ShowMessage:Line(5, true)
    end
    if TotProgress then
      PrBar = TotProgress:Step(TotalStart + nBytesTransferred )
      if PrBar then
        ShowMessage.Strings[10] = PrBar
        ShowMessage:Line(10, true)
      end
    end
    if ShowMessage.LastPos then
      --local s1,s3='Скопировано', SparseIntToStr(nBytesTransferred)..' из '..SparseIntToStr(nTotFSize)..' ('.. percents .. '%)'
      local s1,s3='Скопировано', far.FormatFileSize(nBytesTransferred, 0, "FFFS_COMMAS")..' из '..far.FormatFileSize(nTotFSize, 0, "FFFS_COMMAS")..' ('.. percents .. '%)'
      local s2 = (' '):rep(ShowMessage.LastPos.Width - (s1:len()+s3:len()) - 2*ShowMessage.margins)
      ShowMessage.Strings[6] =  s1..s2..s3
      ShowMessage:Line(6, true)
      if tStart > 0 then
        local tElapsed = tNow - tStart -- прошло времени (милисекунды)
        s1 = 'Прошло '..os.date('!%H:%M:%S', tElapsed/1000)
        local vel=(nBytesTransferred) / (tElapsed/1000) -- скорость байт/с
        s3 = 'Осталось: '..(os.date('!%H:%M:%S', BAX_Round((nTotFSize - nBytesTransferred) / vel)) or '00:00:00')
        s2 = mf.strpad(BAX_Round( vel / 1024 ) .. ' КБайт/с', ShowMessage.LastPos.Width - (s1:len()+s3:len()) - 2*ShowMessage.margins, ' ',2)
        ShowMessage.Strings[7] = s1 .. s2 .. s3
        ShowMessage:Line(7, true)
      end;
      if TotProgress then
        --s1,s3='Всего', SparseIntToStr(TotalStart + nBytesTransferred)..' из '..SparseIntToStr(TotalCount)..' ('.. BAX_Round( (TotalStart + nBytesTransferred) * 100 / TotalCount ) .. '%)'
        s1,s3='Всего', far.FormatFileSize(TotalStart + nBytesTransferred, 0, "FFFS_COMMAS")..' из '..far.FormatFileSize(TotalCount, 0, "FFFS_COMMAS")..' ('.. BAX_Round( (TotalStart + nBytesTransferred) * 100 / TotalCount ) .. '%)'
        s2 = (' '):rep(ShowMessage.LastPos.Width - (s1:len()+s3:len()) - 2*ShowMessage.margins)
        ShowMessage.Strings[11] =  s1..s2..s3
        ShowMessage:Line(11, true)
        ------------------------
        local tElapsed = tNow - tTotalStart -- прошло времени (милисекунды)
        s1 = 'Прошло '..os.date('!%H:%M:%S', tElapsed/1000)
        local vel=(TotalStart + nBytesTransferred) / (tElapsed/1000) -- скорость байт/с
        s3 = 'Осталось: '..(os.date('!%H:%M:%S', BAX_Round((TotalCount - (TotalStart + nBytesTransferred)) / vel)) or '00:00:00')
        s2 = mf.strpad(BAX_Round( vel / 1024 ) .. ' КБайт/с', ShowMessage.LastPos.Width - (s1:len()+s3:len()) - 2*ShowMessage.margins, ' ',2)
        ShowMessage.Strings[12] = s1 .. s2 .. s3
        ShowMessage:Line(12, true)
        ------------------------
      end
    end
    far.Text()
    if mf.waitkey(1, 0) == 'Esc' then
      local ans = far.Message('Прервать копирование?','Копирование файла',';YesNo', 'w')
      if ans == 1 then
        lResult = false
        return 2 --PROGRESS_STOP - Остановить операцию копирования. Она может быть перезапущена в более позднее время.
      else
        -- Перерисовка ВСЕГО окна
        ShowMessage.LastPos = nil
        ShowMessage:Show(nil, false)
      end
    end
    return 0
  end)

  local inPathW, outPathW = ffi.cast( "LPCWSTR",win.Utf8ToUtf16([[\\?\]]..inPath..'\0') ), ffi.cast( "LPCWSTR",win.Utf8ToUtf16([[\\?\]]..outPath..'\0') )
  nTotFSize = win.GetFileInfo(inPath).FileSize
  ProgressBar.maxValue = nTotFSize


  lResult = true
  Strings[1] = inPath
  Strings[3] = outPath
  --ShowMessage.Title="Копирование файла..."
  --ShowMessage.Strings = Strings
  --ShowMessage.delayed = true
  ShowMessage.Width = nil
  ShowMessage.LastPos = nil
  ShowMessage:Show(Strings)
  tStart = Far.UpTime
  tLast = 0
  ffi.C.CopyFileExW(
    inPathW,                     -- LPCWSTR lpExistingFileName,
    outPathW,                    -- LPCWSTR lpNewFileName,
    cbfc,                        -- LPPROGRESS_ROUTINE lpProgressRoutine
    nil,                         -- LPVOID lpData,
    pbCancel,                    -- LPBOOL pbCancel,
    0x00000002                   -- DWORD dwCopyFlags=COPY_FILE_RESTARTABLE -- Написано, что так медленнее. А на самом деле - быстрее
  )

  far.AdvControl("ACTL_REDRAWALL")

  cbfc:free()

  return lResult, resRewrite
end -- CopyFileEx_Lua

function ANSItoUTF_8(str)
  return win.WideCharToMultiByte(win.MultiByteToWideChar(str, win.GetACP()), 65001)
end

function UTF_8ToANSI(str)
  return win.WideCharToMultiByte(win.MultiByteToWideChar(str, 65001), win.GetACP())
  --return win.WideCharToMultiByte(win.Utf8ToUtf16(str),win.GetACP())
end

function RemDir(_, fullname) -- удалить файл или каталог со всем содержимым
 if win.GetFileAttr(fullname):find("d") then -- каталог?
  far.RecursiveSearch(fullname,"*",RemDir) -- почистим его
  win.RemoveDir(fullname) -- и удалим
 else -- файл
  win.DeleteFile(fullname) -- удалим
 end
end

local ChoiceSubFolder_Result=nil

function ChoiceSubFolder(Proc, Filt)
 ChoiceSubFolder_Result=nil
 local DlgId=win.Uuid('12BDA210-CB9F-4191-9950-4EB9AD405AE5')
 local Lst={}
 for i=1,APanel.ItemCount do
  -- Проверка доп. условия. Условие может быть функцией, строкой (с маской, в т.ч. и вида "*.*|Exclude.qqq")
  -- или массивом масок (хотя бы одна соответствует)
  local function _CheckFName(fname)
   -- Проверка по маске с исключением
   local function _ChFNMask(Mask)
    local vert=Mask:find('|')
    if vert then
     return far.ProcessName('PN_CMPNAME', Mask:sub(1,vert-1), fname) and
            not far.ProcessName('PN_CMPNAME', Mask:sub(vert+1), fname)
    else
     return  far.ProcessName('PN_CMPNAME', Mask)
    end
   end -- _ChFNMask
   local bRes=true
   if type(Filt) == 'function' then
    bRes = Filt(fname)
   elseif type(Filt) == 'string' then
    bRes = _ChFNMask(Filt)
   elseif type(Filt) == 'table' then
    bRes = false
    for _,v in ipairs(Filt) do
     bRes = _ChFNMask(v)
     if bRes then break end
    end
   end
   return bRes
  end -- _CheckFName
  local attr, fname=Panel.Item(0,i, 2), Panel.Item(0, i, 0)
  -- Список подпапок.
  if ( band(attr, 0x00000010) == 0x00000010 ) and -- Panel.Item
     ( band(attr, 0x00000002+0x00000004) == 0 ) and -- not (FILE_ATTRIBUTE_HIDDEN or FILE_ATTRIBUTE_SYSTEM)
     ( not fname:match('^%.%.?$') ) and -- not .. and not .
     ( _CheckFName(fname) )
  then
    Lst[#Lst+1] = {Text=fname}
  end
 end
 local APanel_Rect, PPanel_Rect=panel.GetPanelInfo(nil, 1).PanelRect, panel.GetPanelInfo(nil, 0).PanelRect
 local x1,y1,x2,y2 = APanel_Rect.left+2, APanel_Rect.top+2, APanel_Rect.right-2, APanel_Rect.bottom-2
 local vx1,vy1,vx2,vy2 = PPanel_Rect.left+1, PPanel_Rect.top, PPanel_Rect.right-1, PPanel_Rect.bottom-2
 local DlgItems = {}
 --DlgItems[#DlgItems+1] = {'DI_DOUBLEBOX',1,1,0,0,0,0,0,0,'test'}
 DlgItems[#DlgItems+1] = {'DI_LISTBOX', 1,1,x2-4,y2-6, Lst, 0,0,{DIF_LISTNOCLOSE=1},'Меню'}
 DlgItems[#DlgItems+1] = {'DI_BUTTON', 0,y2-5,0,y2-5,0,0,0,{DIF_CENTERGROUP=1; DIF_DEFAULTBUTTON=1; DIF_FOCUS=1},'Ok'}
 --far.DialogInit('', x1+1,y1+1,x2-1,y2-1,nil, DlgItems, {FDLG_NONMODAL=1})
 local CurrentView=''
 local function DlgProc(hDlg, Msg, Param1, Param2)
  local function CloseView()
   if CurrentView ~= '' then
    for i=1,far.AdvControl('ACTL_GETWINDOWCOUNT') do
     local wi=far.AdvControl('ACTL_GETWINDOWINFO', i)
     if wi.TypeName=="View" and wi.Name==CurrentView then
      far.AdvControl('ACTL_SETCURRENTWINDOW', wi.Pos)
      viewer.Quit()
      --Keys"Esc"
      CurrentView = ''
      return
     end
    end;
   end
  end

  if Msg == F.DN_INITDIALOG then
   if mf.fexist(Lst[1].Text .. [[\Dirinfo.txt]]) then
    viewer.Viewer(Lst[1].Text .. [[\Dirinfo.txt]], '', vx1, vy1, vx2, vy2
                  ,{VF_DISABLEHISTORY=1; VF_NONMODAL=1, VF_IMMEDIATERETURN=1}
                 )
    CurrentView=Viewer.FileName
   end

  elseif Msg == F.DN_CLOSE then
   CloseView()
   if Param1 == 2 then ChoiceSubFolder_Result = hDlg:send('DM_GETTEXT', 1) end
  elseif Msg == F.DN_CONTROLINPUT and
         Param2.EventType == F.KEY_EVENT then
   local Key=far.InputRecordToName(Param2)
   if Param1 == 1 and Key == 'Enter' then
    hDlg:send('DM_CLOSE', 2)
   elseif Param1 == 2 and
          (' Up Down PgUp PgDn CtrlPgUp CtrlPgDn Home End '):find(' '..Key..' ') then
    hDlg:send("DM_SETFOCUS",1)
    --hDlg:send("DM_KEY",1, {Param2})
   end
  elseif Msg == F.DN_LISTCHANGE then
   CloseView()
   if mf.fexist(Lst[Param2].Text .. [[\Dirinfo.txt]]) then
    viewer.Viewer(Lst[Param2].Text .. [[\Dirinfo.txt]], '', vx1, vy1, vx2, vy2
                  ,{VF_DISABLEHISTORY=1; VF_NONMODAL=1, VF_IMMEDIATERETURN=1}
                 )
    CurrentView=Viewer.FileName
   end
   local nw=far.AdvControl('ACTL_GETWINDOWCOUNT')
   for i=1,nw do
    local wi=far.AdvControl('ACTL_GETWINDOWINFO', i)
    if wi.TypeName=='Dialog' and
       wi.Id:send('DM_GETDIALOGINFO').Id == DlgId then
     far.AdvControl('ACTL_SETCURRENTWINDOW', wi.Pos)
    end
   end
  end -- case Msg
 end -- DlgProc
 far.DialogInit(DlgId, x1+1,y1+1,x2-1,y2-1,nil, DlgItems, {FDLG_NONMODAL=1}, DlgProc)
 far.Timer(200,
  function(timer)
   if ChoiceSubFolder_Result then
    timer:Close()
    mf.postmacro(Proc, ChoiceSubFolder_Result)
   end
  end
 )
end -- ChoiceSubFolder

FindOneFile = function(afList)
 for _,v in ipairs(afList) do
  if mf.fexist(v) then
   return v
  end
 end
end

FlagsToNumber = function (Value)
 local Result=0
 if type(Value) == 'string' then
  for w in Value:gmatch('[^| ]+') do Result = bor(Result, F[w]) end
   --Result = F[Value]
 elseif type(Value) == 'table' then
  local _sam=next(Value)
  while _sam do
   Result = bor(Result, F[_sam])
   _sam = next(Value, _sam)
  end
 elseif type(Value) == 'number' then
  Result = Value
 else
  Result = nil
 end
 return Result
end -- FlagsToNumber


TestFarFlag = function(tested, Sample)
 return band(FlagsToNumber(tested) or 0, FlagsToNumber(Sample) or 0) ~= 0
end

-- Диалоговые элемены: задание и получение значения параметров в именованном виде.
local _PosItems={type=1;
                 x1=2; y1=3; x2=4; y2=5;
                 selected=6;checked=6;listitems=6; items=6; vbuf=6; list=6;
                 history=7; mask=8; flags=9;
                 data=10; text=10; srctext=10;
                 maxlength=11; userdata=12;
                 reserved_1=13; reserved_2=14}
DialogItemVal = function(DlgItem, What)
 local i=_PosItems[What:lower()] or What
 return DlgItem[i]
end

DialogItem = function(arg)
 local Result={}
 for i=1,6 do
  Result[i] = 0
 end
 local i=next(arg)
 while i do
  if type(i) == 'number' then Result[i] = arg[i] end
  i = next(arg, i)
 end
 i=next(arg)
 while i do
  if type(i) == 'string' then
   local j=_PosItems[i:lower()]
   if j then
    for jj=#Result,j-1 do if Result[jj] == nil then Result[jj] = 0 end end
    if i == 'Flags' and type(arg[i]) == 'string' then
     Result[j] = FlagsToNumber(arg[i])
    else
     Result[j] = arg[i]
    end
   else
    Result[i] = arg[i] -- "Неопределённые" поля (например, можно добавить Name)
   end
  end
  i = next(arg, i)
 end
 return Result
end

SplitBySpace = function(s)
 local aRes,a={}
 while s ~= '' do
  if s:sub(1,1)=='"' then
   a = s:match('%b""'):sub(2,-2)
   s = s:sub(a:len()+3):match"^%s*(.*)$"
  else
   a = s:match('^%S*')
   s = s:sub(a:len()+1):match"^%s*(.*)$"
  end
  table.insert(aRes, a)
 end
 return aRes
end

do
local cmdl=...
if type(cmdl) == 'string' and cmdl:lower():match"^bax.[%w_]+" then
-- Модуль. Запоминаю
if not _G.BAX then _G.BAX = {} end
if not _G.BAX.BaxUtils then _G.BAX.BaxUtils = {} end
for i,v in pairs(
 { BAX_Round=BAX_Round;                 -- Округлёж. Многие делают; просто чтоб далеко не ходить
   far_InputBox=far_InputBox;           -- Оболочка для far.InputBox с указанием ключевых параметров
   SparseIntToStr=SparseIntToStr;       -- Форматирование целого с разделением на группы цифр
   CopyFileEx_Lua=CopyFileEx_Lua;       -- Процедура копирования файла
   MergeSettings=MergeSettings;         -- Процедура слияния настроек (Old - умолчательные; New - прочитанные из файла
   far_Menu=far_Menu;                   -- far.Menu с предустановленным фильтром
   class_def=class_def;                 -- Функция-генератор нового класса
   class_ProgressBar=class_ProgressBar; -- Класс рисования прогресс-бара
   class_ShowMessage=class_ShowMessage; -- Класс вывода строк на экран через far.Text(...)
   far_InputForm=far_InputForm;         -- Процедура ввода нескольких значений аналогично far.InputBox
   ANSItoUTF_8=ANSItoUTF_8;             -- Преобразование Ansi -> UTF-8
   UTF_8ToANSI=UTF_8ToANSI;             -- И обратно
   RemDir=RemDir;                       -- Удаление каталога с подкаталогами
   ChoiceSubFolder=ChoiceSubFolder;     -- Выбор подпапки с показом DirInfo и выполнением процедуры
   FindOneFile = FindOneFile;           -- Поиск одного файла из нескольких. Возвращает либо имя найденного файли, либо nil
   FlagsToNumber = FlagsToNumber;       -- Преобразование far-флагов из различных представалений (строки - в т.ч. и через "|", таблицы) в число
   TestFarFlag = TestFarFlag;           -- Проверка наличия флага (с учётом того, что флаги могут быть числом, строкой и таблицей)
   DialogItem = DialogItem;             -- Преобразование ключевого представления элемента диалога в позиционное
   DialogItemVal = DialogItemVal;       -- Получение значения параметра диалогового итема по имени
   SplitBySpace = SplitBySpace          -- Разбивка строки по пробелам в таблицу. Если элемент заключён в '"', то не разбивается.
 }) do
 _G.BAX.BaxUtils[i] = v
end

-- Аналог mf.mdelete, но name может быть маской (как в поиске файлов)
function _G.BAX.BaxUtils.mDelete(key, name, location)
 local function CheckRE(mask)
  if mask == '*' then return false
  elseif ( mask:match"^/(.*)/([ismx]*)$" and   -- регэксп
           pcall(regex.matchW, '', mask)
         )
   then return true
  elseif mask:find('*',1,true) or          -- В имени ключа имеются
         mask:find('?',1,true) or          -- спецсимволы "*" и "?"
         mask:find(',',1,true) then
   return true
  end
  return false
 end
 local ret = false
 if not CheckRE(name) then
  ret = mf.mdelete (key, name, location)
 else
  local obj = far.CreateSettings(nil, location=="local" and "PSL_LOCAL" or "PSL_ROAMING")
  if obj then
   local subkey = obj:OpenSubkey(0, key)
   if subkey then
    local keys = obj:Enum(subkey)
    if keys and #keys > 0 then
     for _,v in ipairs(keys) do
      local KeyName=v.Name
      if far.ProcessName(F.PN_CMPNAMELIST, name, KeyName) then
       ret = obj:Delete(subkey, KeyName) or ret
      end
     end -- for _,v in ipairs(keys)
    end -- if keys and #keys > 0
   end -- if subkey
   ret = (subkey or false) and obj:Delete(subkey, name~="*" and name or nil)
   obj:Free()
  end -- of obj
 end -- if iCheckRE == nil
 return ret
end -- mDelete


return _G.BAX.BaxUtils
else -- Не модуль - для отладки
 --------- Конец отладки ---------
 return
end
end