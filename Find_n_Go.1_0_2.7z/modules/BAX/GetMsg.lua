--[[
Версия 4.
 1. Реализованы "многострочные строки"
 2. Реализовано указание функции вместо строки
Версия 3.
Учтены некоторые замечания [ref=#006600]John Doe[/ref] [url=https://forum.farmanager.com/viewtopic.php?p=151330#p151330](тут)[/url]
Версия 2.
Для символьного тега добавлен поиск по "личным" настроечным файлам
Версия 1.
Заменитель - расширитель far.GetMsg
Варианты вызова:
GetMsg( <number> ) - стандартный far.GetMsg
GetMsg( <имя_файла>, <Тег> ) - расширение.
<имя_файла> - имя языкового файла (возможно, без "языкового окончания"). Например, EMenu, EMenu.lng, esc_rus.lng
              Если расширение не указано - предполагается .lng
              Если указанный файл не найден, то ищется последовательно <имя>lang, <имя>_lang, <имя>langh, <имя>_langh, где
                lang - первые 3 символа настройки языка ФАРа; langh - то же для языка помощи
<Тег> - либо номер (тот же, что указывается в far.GetMsg), либо символьная строка, указанная в языковом файле в виде
        строки //[Тег] (см., например, %FarHome%\FarRus.lng)
-- ]]
--local BaxUtils=require"Bax.BaxUtils"

local Info = package.loaded.regscript or function(...) return ... end
local nfo = Info {_filename or ...,
  name        = "";
  description = "\"Расширение\" стандартной GetMsg";
  version     = "1.4.1";
  author      = "BAX";
  url         = "https://forum.farmanager.com/viewtopic.php?p=151277";
  id          = "13230B42-55DE-48DA-91ED-CF2B17B95A07";
  --parent_id   = "";
  --minfarversion = {3,0,0,4744,0};
  --files       = "*.cfg;*.ru.lng";
  --config      = function(nfo,name) end;
  help        = function(nfo,name)
                 far.Message( --"Расширение GetMsg:\n\1\n"..
[[   Добавлены возможности:
1. Указывать имя языкового файла;
2. В качестве тега указывать строку; в языковом файле он должен присутствовать в отдельной строке в формате //[тег]
3. Указывать только имяпроекта, если имя языкового файла состоит из имени проекта и 3-символьного имени языка
4. В качестве строки допустимо любое валидное LUA-выражение
]]..'\1'..[=[

Вызов:
GetMsg(File, Tag [,Quiet [,AddArgs]]
где:
  File, Tag - понятно;
  Quiet=true - подавляет сообщение об ошибке
  AddArgs - дополнительные параметры, если в качестве строки указана функция]=],
                             'BAX - GetMsg', nil, 'l')
                end;
  --execute     = function(nfo,name) end;

  --disabled    = false;
  --options     = {};
}
if not nfo then return end
--local O = nfo.options

local GetMsg =
function (...)
 local Res
 --if #{...} == 1 and tonumber(...) then
 if select("#",...)==1 and type(...)=="number" then
  return far.GetMsg(...)
 end

 local Args=...
 if type(Args) ~= 'table' then
  local ar={...}
  Args = {File=ar[1]; Tag=ar[2]; Quiet=ar[3]; AddArgs={unpack(ar,4)}}
 end
 local File, Tag, Quiet, AddArgs=Args.File, Args.Tag, Args.Quiet, Args.AddArgs or {}
 if File and Tag then
  local function CheckFN_(s)
   if win.GetFileInfo(s) then
    File = s
    return true
   end
  end
  local function SeekTag(AFile, xTag, bCustom)
   local sRes
   local hFile=io.open(AFile, 'r')
   if hFile then
    local Found, iTag=false, -1
    local asRes=nil
    for Line in hFile:lines() do
     -- Столкнулся с ситуацией, когда в начале файла - сигнатура UTF-8 (BOM). Попытка тупо удалить.
     -- Наверняка есть более корректный способ, но на выводе BOM не виден.
     if string.byte(Line,1) == 239 and    -- 0xEF
        string.byte(Line,2) == 187 and    -- 0xBB
        string.byte(Line,3) == 191 then   -- 0xBF
      Line = string.sub(Line,4)
     end
     Line = Line:match('^%s*(.-)%s*$')
     if bCustom then
      sRes = Line:match('^'..xTag..'%s*=%s*(%b"")')
      if sRes then
       sRes = sRes:sub(2,-2)
       break
      end
     elseif type(xTag) == 'string' then
      if Found then
       if Line:match"^//%[[^%[%]]+%]$" then
        -- Найден следующий тег
        break
       elseif not Line:match"^//" then
        if asRes == nil then asRes = {} end
        table.insert(asRes, Line)
       end
      else
       Found = Line == '//[' .. xTag .. ']'
      end
     else
      iTag = iTag + 1
      if iTag == xTag then
       sRes = Line:sub(2,-2)
       break
      end
     end
    end
    hFile:close()
    if type(asRes) == 'table' then
     for i=#asRes,1,-1 do
      if asRes[i]:match"%S" then
       break
      else
       table.remove(asRes, i)
      end
     end
     local xFun=loadstring('return '..table.concat(asRes, '\n'))
     if type(xFun) ~= 'function' then
      if not Quiet then far.Message('Некорректное выражение для строки '..tostring(xTag), 'GetMsg', nil, 'w') end
      return
     else
      xFun = xFun()
     end
     if type(xFun) == 'function' then
      sRes = xFun(unpack(AddArgs))
     else
      sRes = xFun
     end
    end
   end
   Res = sRes
   return sRes
  end -- of function SeekTag
  if not win.GetFileInfo(File) then
   local lang=(Far.GetConfig('Language.Main') or win.GetEnv('FARLANG') or 'English'):sub(1,3)
   local langh=(Far.GetConfig('Language.Help') or win.GetEnv('FARLANG') or 'English'):sub(1,3)
   local PathN, Ext=mf.fsplit(File, 7), mf.fsplit(File, 8)
   for w in PathN:gmatch('%%[^%%]+%%') do
    PathN = PathN:gsub( '%'..w..'%',win.GetEnv(w:sub(2,-2)) )
   end

   if Ext =='' then Ext = '.lng' end
   if not ( CheckFN_(PathN..Ext) or
            CheckFN_(PathN..lang..Ext) or
            CheckFN_(PathN..'_'..lang..Ext) or
            CheckFN_(PathN..langh..Ext) or
            CheckFN_(PathN..'_'..langh..Ext) or
            CheckFN_(PathN..'Eng'..Ext) or
            CheckFN_(PathN..'_'..'Eng'..Ext)
          ) then
    if not Quiet then far.Message('Языковой файл '..PathN..'[[_]'..lang..'] не найден', 'GetMsg', nil, 'w') end
   end
  end
  if win.GetFileInfo(File) then
   local File0 = File
   if type(Tag) == 'string' and
      ( ( CheckFN_(File .. '.custom') and SeekTag(File, Tag, true) ) or
        --false
        ( CheckFN_(win.GetEnv('FARHOME') .. '\\' .. mf.fsplit(File0, 12) .. '.custom') and SeekTag(File, Tag, true) ) or
        ( CheckFN_(win.GetEnv('FARPROFILE') .. '\\' .. mf.fsplit(File0, 12) .. '.custom') and SeekTag(File, Tag, true) )
      ) then
    return Res
   end
   return SeekTag(File0, Tag, false)
  end
 else
  if not Quiet then far.Message("Требуется указать File= и Tag=", 'GetMsg', nil, 'w') end
 end
 return Res
end -- of function GetMsg
-- Делаю "личный" подраздел _G и записываю туда эту функцию
if not _G.BAX then _G.BAX = {} end
_G.BAX.GetMsg = GetMsg

--return
---- GetMsg([[C:\Temp\190820\qqq.lng]], 'string'),
---- GetMsg([[C:\Temp\190820\qqq.lng]], 'Test1', false, mf.date('%Y')),
---- GetMsg([[C:\Temp\190820\qqq.lng]], 'Test2', false),
-- GetMsg([[C:\Temp\190820\qqq.lng]], 'Test3', false, 10),
--nil
